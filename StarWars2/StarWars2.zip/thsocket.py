import socket
import threading


class Server(threading.Thread):

    def __init__(self, game, ship, asteroid, shoot):
        super(Server, self).__init__()
        self.sock = socket.socket()
        self._server = False
        self.crash = False
        self.ship = ship
        self.game = game
        self.shoot = shoot
        self.asteroid = asteroid

    def run(self):
        self.sock.bind(('', 4747))
        self.sock.listen(1)
        self.sock.settimeout(.5)
        while not (self._server or self.crash):
            try:
                self.conn, addr = self.sock.accept()
                self.conn.settimeout(.5)
                self._server = True
                while self._server and not self.crash:
                    self.check(_recv(self.conn))
            except:
                pass

    def check(self, data):
        if data:
            for i in data.split('*'):
                if not i:
                    continue
                j = i.split()[0]
                if j == 'lost':
                    self._server = False
                elif j == 'restart':
                    self.game.restart((150, 400), (350, 400))
                elif j == 'shoot':
                    self.shoot.x, self.shoot.y = (int(i.split()[1]), int(i.split()[2]))
                    if self.shoot.x != -1:
                        self.shoot.playSong('shoot.mp3')
                    if self.shoot.x == -1:
                        self.game.player2 += 1
                elif j == 'asteroid':
                    self.asteroid.x, self.asteroid.y = (int(i.split()[1]), int(i.split()[2]))
                elif j == 'ship':
                    self.ship.x_change, self.ship.y_change = (int(i.split()[1]), int(i.split()[2]))

    def send(self, data):
        _send(self.conn, data)

    def isServer(self):
        if self._server:
            return True
        return False

    def close(self):
        self.crash = True
        if self._server:
            self.send('lost ')


class Client(threading.Thread):

    def __init__(self, game, ship, asteroid, shoot):
        super(Client, self).__init__()
        self.sock = socket.socket()
        self._client = False
        self.crash = False
        self.ship = ship
        self.game = game
        self.shoot = shoot
        self.asteroid = asteroid

    def connect(self, host=''):
        try:
            self.sock.connect((host, 4747))
            self._client = True
            self.send('restart ')
            self.game.restart((350, 400), (150, 400))
            return True
        except:
            return False

    def run(self):
        self.sock.settimeout(.5)
        while not self.crash:
            self.check(_recv(self.sock))

    def check(self, data):
        if data:
            for i in data.split('*'):
                if not i:
                    continue
                j = i.split()[0]
                if j == 'lost':
                    self._client = False
                elif j == 'shoot':
                    self.shoot.x, self.shoot.y = (int(i.split()[1]), int(i.split()[2]))
                    if self.shoot.x != -1:
                        self.shoot.playSong('shoot.mp3')
                    if self.shoot.x == -1:
                        self.game.player1 += 1
                elif j == 'asteroid':
                    self.asteroid.x, self.asteroid.y = (int(i.split()[1]), int(i.split()[2]))
                elif j == 'ship':
                    self.ship.x_change, self.ship.y_change = (int(i.split()[1]), int(i.split()[2]))

    def send(self, data):
        _send(self.sock, data)

    def isClient(self):
        if self._client:
            return True
        return False

    def close(self):
        self.crash = True
        self.send('lost ')


### helper functions ###

def _send(connection, data):
    data = bytes(data, 'utf-8')
    try:
        connection.send(data)
    except:
        pass


def _recv(connection):
    try:
        data = connection.recv(1024)
        data = data.decode('utf-8')
        return data
    except:
        return None
