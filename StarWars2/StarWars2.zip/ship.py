import pygame


class Ship:
    def __init__(self):
        self.x = 150
        self.y = 400
        self.x_change = 0
        self.y_change = 0
        self.image = pygame.image.load('ship.png')

    def updatePosition(self, event):
        # If key is DOWN
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.x_change = -1
            if event.key == pygame.K_RIGHT:
                self.x_change = 1
            if event.key == pygame.K_DOWN:
                self.y_change = 1
            if event.key == pygame.K_UP:
                self.y_change = -1

        # If key is UP
        keys = pygame.key.get_pressed()
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                if keys[pygame.K_RIGHT]:
                    self.x_change = 1
                else:
                    self.x_change = 0
            if event.key == pygame.K_RIGHT:
                if keys[pygame.K_LEFT]:
                    self.x_change = -1
                else:
                    self.x_change = 0
            if event.key == pygame.K_UP:
                if keys[pygame.K_DOWN]:
                    self.y_change = 1
                else:
                    self.y_change = 0
            if event.key == pygame.K_DOWN:
                if keys[pygame.K_UP]:
                    self.y_change = -1
                else:
                    self.y_change = 0

    def draw(self, game):
        # Checking ship position
        if 0 < self.x + self.x_change < 473:
            self.x += self.x_change
        if 200 < self.y + self.y_change < 468:
            self.y += self.y_change

        game.gameDisplay.blit(self.image, (self.x, self.y))
